<ul class="nav nav-list">
              <li class="nav-header">Main</li>
              <li><a href="main.php">Home</a></li>
              
              <?php if ($username=='admin') :?>
              <li class="nav-header">User Management</li>
              <li><a href="user.php">User</a></li>
              <li class="nav-header">Database</li>
              <li><a href="phpmyadmin/index.php">Database administration</a></li>
              <?php endif;?>
              
              <li class="nav-header">Hike Guide</li>
              <li><a href="hg_main.php">Guide Overview</a></li>
              <li><a href="hg_creator.php">Guide Creator</a></li>
			  <li><a href="hg_editor.php">Guide Editor</a></li>   
              <li><a href="hg_publisher.php">Guide Publisher</a></li>
              
              <li class="nav-header">Downloads</li>
              <li><a href="apk/FerndaleForms2.apk">Mobile application</a></li>
              <li class="nav-header">Help</li>
              <li><a href="">Help topics</a></li>
              
              
            </ul>