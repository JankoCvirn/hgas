<?php
	if(!defined('CLASS_ESME')) {
	    define('CLASS_ESME', true);

		
		define('db336885_7','db336885_7'); 
		
		
		/* Add more constants for other databases as needed */
	}
?>
